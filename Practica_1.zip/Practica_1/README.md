# Mapa de Bits

Desarrolle una aplicación que permita crear un mapa de bits a partir de una imagen cualquiera, es decir, deberán cargar una imagen al programa, este leerá la información de dicha imagen y la almacenará en un array.

# Explicación

Para mi fue complicado encontrar algun ejemplo o explicación que mostrara cómo realizar el paso de imagen a un BitMap, y una vez lo encontré me encontré con otro problema pasarlo el cual era pasarlo a otro color
por el tiempo que tomó la investigación y lo poco que logré comprender, ya que mucha información está en inglés fue cambiar los colores a blanco y negro
pasando de imagen a BitMap y tomando eso con un for pasar por él y cambiar el color

# Código

Por motivos de inexperiencia le comparto el link de la imagen

(Capturas del código)

https://drive.google.com/file/d/1l-cNifjBC8eHG7NZzoQ8cNaafEgXc6Ld/view?usp=sharing

https://drive.google.com/file/d/14DegPHtb8EC9A1xmwoyFQ8vou1wp5CN4/view?usp=sharing

# Ejecución

(Capturas de la Aplicación)

https://drive.google.com/file/d/1VbUsUFflXBB2CgbX9djq09bLir3Xrn2F/view?usp=sharing

https://drive.google.com/file/d/162tePxspK6l8DUdeS76ssLvW4WNSXCnv/view?usp=sharing

https://drive.google.com/file/d/1ZCkJyG0BMsqGbx8AF5kj7auZ4BEzMDqv/view?usp=sharing
